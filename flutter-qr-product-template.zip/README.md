# Flutter QR Product Scanner - Template Repo

This repository is a **template** to run inside **GitHub Codespaces** and produce an Android APK that:

- Scans QR codes containing a **Product ID** (e.g., `P123`, `SKU001`)
- Calls a **Google Apps Script** endpoint to fetch product details
- Shows the product details on screen

---

## What this repo contains
- `.devcontainer/` — Codespaces configuration (Dockerfile + post-create script)
- `pubspec.yaml` — dependencies (mobile_scanner, http)
- `lib/main.dart` — Flutter app (QR scan + HTTP fetch)
- `apps_script/sample.gs` — example Apps Script web app
- Instructions below to finish setup.

---

## Quick steps (recommended)

1. Open this repo in **GitHub Codespaces**.
2. Wait for Codespace to start (the `.devcontainer/post-create.sh` will run).
3. **If you opened an empty folder**, run:
   ```bash
   flutter create .
   ```
   This generates the platform folders (android/ ios/) required for building.
4. Get dependencies:
   ```bash
   flutter pub get
   ```
5. Update `lib/main.dart` constants at top with your Apps Script URL and API key:
   ```dart
   const String SCRIPT_BASE_URL = "https://script.google.com/macros/s/REPLACE_WITH_YOUR_SCRIPT_ID/exec";
   const String API_KEY = "REPLACE_WITH_API_KEY";
   ```
6. Build APK:
   ```bash
   flutter build apk --release
   ```
   APK will be at `build/app/outputs/flutter-apk/app-release.apk`

---

## Apps Script example

See `apps_script/sample.gs` — deploy it as a Web App (Execute as: **Me**, Access: **Anyone with link**).
Add a simple API key check and a sheet lookup.

---

## Notes

- The repo is a template. If flutter project structure (android/) is missing, run `flutter create .` to generate it.
- The `.devcontainer` installs Android command-line tools and Flutter. `post-create.sh` runs `sdkmanager` installs and `flutter doctor`.
- On some Codespaces environments you may need to accept licenses: `yes | sdkmanager --licenses`.

If you want, I can:
- Push this to a GitHub repo for you
- Generate the full Flutter project (including android/) and upload the ZIP
- Provide a ready-to-deploy Apps Script with sheet sample

Reply with **"push to GitHub"** or **"upload full project zip"** to continue.
