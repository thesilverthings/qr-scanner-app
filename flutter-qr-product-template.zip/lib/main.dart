import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const MyApp());
}

/// Replace these with your Apps Script URL and API key.
const String SCRIPT_BASE_URL = "https://script.google.com/macros/s/REPLACE_WITH_YOUR_SCRIPT_ID/exec";
const String API_KEY = "REPLACE_WITH_API_KEY";

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QR Product Scanner',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const QRScannerPage(),
    );
  }
}

class QRScannerPage extends StatefulWidget {
  const QRScannerPage({super.key});
  @override
  State<QRScannerPage> createState() => _QRScannerPageState();
}

class _QRScannerPageState extends State<QRScannerPage> {
  String result = "Scan a QR Code that contains Product ID (e.g., P123)";
  bool scanning = true;
  MobileScannerController cameraController = MobileScannerController();

  Future<void> scanProduct(String productId) async {
    setState(() {
      result = "Looking up product $productId ...";
      scanning = false;
    });
    try {
      final uri = Uri.parse(SCRIPT_BASE_URL).replace(queryParameters: {
        'id': productId,
        'key': API_KEY,
      });
      final resp = await http.get(uri).timeout(const Duration(seconds: 10));
      if (resp.statusCode == 200) {
        // Expect JSON response from Apps Script
        final data = json.decode(resp.body);
        setState(() {
          result = JsonEncoder.withIndent('  ').convert(data);
        });
      } else {
        setState(() {
          result = 'Server returned ${resp.statusCode}: ${resp.body}';
        });
      }
    } catch (e) {
      setState(() {
        result = 'Error: $e';
      });
    } finally {
      // resume scanning after short delay
      await Future.delayed(const Duration(seconds: 2));
      setState(() {
        scanning = true;
      });
    }
  }

  @override
  void dispose() {
    cameraController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('QR Product Scanner'),
        actions: [
          IconButton(
            icon: const Icon(Icons.flip_camera_ios),
            onPressed: () => cameraController.switchCamera(),
          ),
          IconButton(
            icon: const Icon(Icons.flash_on),
            onPressed: () => cameraController.toggleTorch(),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 4,
            child: scanning
                ? MobileScanner(
                    controller: cameraController,
                    onDetect: (capture) {
                      final List<Barcode> codes = capture.barcodes;
                      if (codes.isNotEmpty) {
                        final code = codes.first.rawValue ?? '';
                        if (code.isNotEmpty) {
                          scanProduct(code);
                        }
                      }
                    },
                  )
                : Container(
                    color: Colors.black,
                    child: const Center(child: Text('Processing...', style: TextStyle(color: Colors.white))),
                  ),
          ),
          Expanded(
            flex: 3,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Text(result),
            ),
          ),
        ],
      ),
    );
  }
}
